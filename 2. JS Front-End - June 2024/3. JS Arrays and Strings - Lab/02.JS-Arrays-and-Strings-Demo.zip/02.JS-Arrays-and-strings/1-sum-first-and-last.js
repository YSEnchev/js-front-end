function solve(input) {
    const first = input.shift();
    const last = input.pop();

    console.log(first + last);
}

solve([20, 30, 40]);
